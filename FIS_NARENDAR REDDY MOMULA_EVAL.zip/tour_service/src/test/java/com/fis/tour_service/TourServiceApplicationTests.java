package com.fis.tour_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
